'use client';

import { useState } from 'react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Legend,
  Tooltip,
  Sector,
} from 'recharts';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useFinanceStore } from '@/lib/store';
import { getCategoryData, formatCurrency } from '@/lib/data';

// Custom active shape component for the pie chart
const renderActiveShape = (props: any) => {
  const {
    cx, cy, innerRadius, outerRadius, startAngle, endAngle,
    fill, payload, percent, value
  } = props;

  return (
    <g>
      <text x={cx} y={cy - 5} dy={8} textAnchor="middle" fill={fill} className="text-base font-medium">
        {payload.category}
      </text>
      <text x={cx} y={cy + 20} dy={8} textAnchor="middle" fill="#999" className="text-sm">
        {formatCurrency(value)} ({(percent * 100).toFixed(1)}%)
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius + 5}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
    </g>
  );
};

export function CategoryPieChart() {
  const { transactions } = useFinanceStore();
  const [activeIndex, setActiveIndex] = useState(0);
  const [timeRange, setTimeRange] = useState('all');
  
  // Filter transactions based on selected time range
  const filteredTransactions = transactions.filter(transaction => {
    if (timeRange === 'all') return true;
    
    const transactionDate = new Date(transaction.date);
    const currentDate = new Date();
    
    if (timeRange === 'month') {
      return (
        transactionDate.getMonth() === currentDate.getMonth() &&
        transactionDate.getFullYear() === currentDate.getFullYear()
      );
    } else if (timeRange === 'year') {
      return transactionDate.getFullYear() === currentDate.getFullYear();
    }
    
    return true;
  });
  
  // Process data for the chart
  const categoryData = getCategoryData(filteredTransactions)
    .sort((a, b) => b.amount - a.amount); // Sort by amount (descending)
  
  // Calculate total for the header
  const total = categoryData.reduce((sum, item) => sum + item.amount, 0);
  
  // Handle pie slice hover
  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="space-y-1">
          <CardTitle>Category Breakdown</CardTitle>
          <CardDescription>
            Total: {formatCurrency(total)}
          </CardDescription>
        </div>
        <Select
          value={timeRange}
          onValueChange={setTimeRange}
        >
          <SelectTrigger className="w-[120px]">
            <SelectValue placeholder="Select range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="month">This Month</SelectItem>
            <SelectItem value="year">This Year</SelectItem>
            <SelectItem value="all">All Time</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent className="h-80">
        {categoryData.length > 0 ? (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                activeIndex={activeIndex}
                activeShape={renderActiveShape}
                innerRadius={60}
                outerRadius={90}
                dataKey="amount"
                onMouseEnter={onPieEnter}
                paddingAngle={2}
              >
                {categoryData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={entry.color} 
                  />
                ))}
              </Pie>
              <Legend 
                layout="vertical" 
                verticalAlign="middle" 
                align="right"
                formatter={(value, entry, index) => (
                  <span style={{ color: categoryData[index]?.color }}>
                    {value}
                  </span>
                )}
              />
              <Tooltip 
                formatter={(value) => formatCurrency(value as number)}
              />
            </PieChart>
          </ResponsiveContainer>
        ) : (
          <div className="flex h-full items-center justify-center">
            <p className="text-muted-foreground">No data available</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}