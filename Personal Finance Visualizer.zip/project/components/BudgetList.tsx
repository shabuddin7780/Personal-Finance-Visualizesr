'use client';

import { useState } from 'react';
import { Plus, PencilIcon, Trash2Icon } from 'lucide-react';
import { format, parseISO } from 'date-fns';

import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { BudgetForm } from '@/components/BudgetForm';
import { formatCurrency, getCategoryById } from '@/lib/data';
import { useFinanceStore } from '@/lib/store';
import { Budget } from '@/lib/types';
import { Progress } from '@/components/ui/progress';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

export function BudgetList() {
  const { budgets, transactions, deleteBudget } = useFinanceStore();
  const [selectedBudget, setSelectedBudget] = useState<Budget | null>(null);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);

  // Group budgets by month
  const groupedBudgets: Record<string, Budget[]> = {};
  budgets.forEach(budget => {
    if (!groupedBudgets[budget.month]) {
      groupedBudgets[budget.month] = [];
    }
    groupedBudgets[budget.month].push(budget);
  });

  // Sort months in descending order
  const sortedMonths = Object.keys(groupedBudgets)
    .sort((a, b) => b.localeCompare(a));

  // Calculate actual spending for each budget
  const getActualSpending = (budget: Budget) => {
    return transactions
      .filter(t => 
        t.type === 'expense' && 
        t.categoryId === budget.categoryId && 
        t.date.startsWith(budget.month)
      )
      .reduce((sum, t) => sum + t.amount, 0);
  };

  // Calculate progress percentage for progress bar
  const calculateProgress = (actual: number, budget: number) => {
    return Math.min(Math.round((actual / budget) * 100), 100);
  };

  const handleEdit = (budget: Budget) => {
    setSelectedBudget(budget);
    setIsEditOpen(true);
  };

  const handleDelete = (id: string) => {
    deleteBudget(id);
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Budgets</h2>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Budget
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Add Budget</DialogTitle>
              <DialogDescription>
                Set a spending limit for a category.
              </DialogDescription>
            </DialogHeader>
            <BudgetForm onSuccess={() => setIsAddOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      {sortedMonths.length > 0 ? (
        sortedMonths.map(month => (
          <Card key={month} className="w-full">
            <CardHeader>
              <CardTitle>
                {format(parseISO(`${month}-01`), 'MMMM yyyy')}
              </CardTitle>
              <CardDescription>
                Monthly budget breakdown
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Category</TableHead>
                    <TableHead>Budget</TableHead>
                    <TableHead>Actual</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {groupedBudgets[month].map(budget => {
                    const category = getCategoryById(budget.categoryId);
                    const actual = getActualSpending(budget);
                    const progress = calculateProgress(actual, budget.amount);
                    const isOverBudget = actual > budget.amount;

                    return (
                      <TableRow key={budget.id}>
                        <TableCell>{category?.name || 'Unknown'}</TableCell>
                        <TableCell>{formatCurrency(budget.amount)}</TableCell>
                        <TableCell>{formatCurrency(actual)}</TableCell>
                        <TableCell>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger className="w-full">
                                <Progress 
                                  value={progress} 
                                  className={isOverBudget ? "bg-muted" : ""}
                                  indicatorClassName={
                                    isOverBudget 
                                      ? "bg-destructive" 
                                      : progress > 85 
                                        ? "bg-yellow-500" 
                                        : undefined
                                  }
                                />
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>
                                  {progress}% of budget used
                                  {isOverBudget && ` (${formatCurrency(actual - budget.amount)} over)`}
                                </p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEdit(budget)}
                            >
                              <PencilIcon className="h-4 w-4" />
                              <span className="sr-only">Edit</span>
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDelete(budget.id)}
                            >
                              <Trash2Icon className="h-4 w-4" />
                              <span className="sr-only">Delete</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        ))
      ) : (
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center justify-center space-y-3 py-8">
              <p className="text-muted-foreground">No budgets set yet.</p>
              <Button variant="outline" onClick={() => setIsAddOpen(true)}>
                Create your first budget
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Edit Budget Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit Budget</DialogTitle>
            <DialogDescription>
              Update your budget settings.
            </DialogDescription>
          </DialogHeader>
          {selectedBudget && (
            <BudgetForm
              budget={selectedBudget}
              onSuccess={() => {
                setSelectedBudget(null);
                setIsEditOpen(false);
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}