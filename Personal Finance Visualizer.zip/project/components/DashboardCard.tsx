'use client';

import { 
  ArrowUpRightIcon, 
  ArrowDownRightIcon, 
  CalendarIcon, 
  ArrowDownIcon,
  ArrowUpIcon,
  TrendingUpIcon,
  TrendingDownIcon,
  DollarSignIcon
} from 'lucide-react';

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { formatCurrency } from '@/lib/data';

interface DashboardCardProps {
  title: string;
  value: number;
  type?: 'income' | 'expense' | 'neutral';
  change?: number;
  icon?: React.ReactNode;
}

export function DashboardCard({ 
  title, 
  value, 
  type = 'neutral',
  change,
  icon
}: DashboardCardProps) {
  const isPositive = change && change > 0;
  
  const getTypeColor = () => {
    switch (type) {
      case 'income':
        return 'text-green-600';
      case 'expense':
        return 'text-red-600';
      default:
        return '';
    }
  };
  
  const getIcon = () => {
    if (icon) return icon;
    
    switch (type) {
      case 'income':
        return <TrendingUpIcon className="h-5 w-5 text-green-600" />;
      case 'expense':
        return <TrendingDownIcon className="h-5 w-5 text-red-600" />;
      default:
        return <DollarSignIcon className="h-5 w-5" />;
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">
          {title}
        </CardTitle>
        <div className="h-5 w-5 text-muted-foreground">
          {getIcon()}
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">
          <span className={getTypeColor()}>
            {type === 'income' && '+'}
            {type === 'expense' && '-'}
            {formatCurrency(value)}
          </span>
        </div>
        
        {change !== undefined && (
          <p className="text-xs text-muted-foreground mt-1 flex items-center">
            {isPositive ? (
              <>
                <ArrowUpIcon className="mr-1 h-3 w-3 text-green-500" />
                <span className="text-green-500">
                  {Math.abs(change).toFixed(1)}%
                </span>
              </>
            ) : (
              <>
                <ArrowDownIcon className="mr-1 h-3 w-3 text-red-500" />
                <span className="text-red-500">
                  {Math.abs(change).toFixed(1)}%
                </span>
              </>
            )}
            <span className="ml-1">from last month</span>
          </p>
        )}
      </CardContent>
    </Card>
  );
}