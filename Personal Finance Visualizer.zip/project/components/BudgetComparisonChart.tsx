'use client';

import { useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
} from 'recharts';
import { format, parseISO } from 'date-fns';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useFinanceStore } from '@/lib/store';
import { getBudgetComparisonData, formatCurrency } from '@/lib/data';

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-4 rounded-md shadow-md border border-gray-200">
        <p className="font-bold mb-1">{label}</p>
        {payload.map((entry: any) => (
          <p key={entry.name} style={{ color: entry.color }}>
            {entry.name}: {formatCurrency(entry.value)}
          </p>
        ))}
        {payload.length === 2 && (
          <p className="mt-2 text-sm">
            {payload[0].value > payload[1].value
              ? `Over budget by ${formatCurrency(payload[0].value - payload[1].value)}`
              : `Under budget by ${formatCurrency(payload[1].value - payload[0].value)}`}
          </p>
        )}
      </div>
    );
  }
  return null;
};

export function BudgetComparisonChart() {
  const { transactions, budgets } = useFinanceStore();
  
  // Get current month in YYYY-MM format
  const currentDate = new Date();
  const currentMonth = format(currentDate, 'yyyy-MM');
  
  // Create a list of available months for the dropdown
  const uniqueMonths = Array.from(
    new Set(budgets.map(budget => budget.month))
  ).sort().reverse();
  
  const [selectedMonth, setSelectedMonth] = useState(
    uniqueMonths.includes(currentMonth) ? currentMonth : uniqueMonths[0] || currentMonth
  );
  
  // Process data for the chart
  const comparisonData = getBudgetComparisonData(
    transactions,
    budgets,
    selectedMonth
  );
  
  // Calculate metrics
  const totalBudget = comparisonData.reduce((sum, item) => sum + item.budget, 0);
  const totalActual = comparisonData.reduce((sum, item) => sum + item.actual, 0);
  const difference = totalBudget - totalActual;
  const isOverBudget = difference < 0;
  
  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="space-y-1">
          <CardTitle>Budget vs Actual</CardTitle>
          <CardDescription className="flex items-center">
            <span className={isOverBudget ? 'text-red-500' : 'text-green-500'}>
              {isOverBudget 
                ? `Over budget by ${formatCurrency(Math.abs(difference))}` 
                : `Under budget by ${formatCurrency(difference)}`}
            </span>
          </CardDescription>
        </div>
        <Select
          value={selectedMonth}
          onValueChange={setSelectedMonth}
        >
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Select month" />
          </SelectTrigger>
          <SelectContent>
            {uniqueMonths.map((month) => (
              <SelectItem key={month} value={month}>
                {format(parseISO(`${month}-01`), 'MMMM yyyy')}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent className="h-80">
        {comparisonData.length > 0 ? (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={comparisonData}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              layout="vertical"
            >
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} horizontal={false} />
              <XAxis 
                type="number" 
                tickFormatter={(value) => formatCurrency(value)}
              />
              <YAxis 
                type="category" 
                dataKey="category"
                width={120}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Bar 
                dataKey="actual" 
                name="Actual" 
                fill="hsl(var(--chart-1))" 
                animationDuration={1000}
                radius={[0, 4, 4, 0]}
              />
              <Bar 
                dataKey="budget" 
                name="Budget" 
                fill="hsl(var(--chart-2))" 
                animationDuration={1500}
                radius={[0, 4, 4, 0]}
              />
              <ReferenceLine
                x={0}
                stroke="#666"
                strokeWidth={1}
              />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <div className="flex h-full items-center justify-center">
            <p className="text-muted-foreground">No budget data available for this month</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}