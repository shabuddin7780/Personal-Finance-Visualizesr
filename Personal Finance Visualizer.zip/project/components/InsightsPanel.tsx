'use client';

import { useFinanceStore } from '@/lib/store';
import { DashboardSummary } from '@/lib/types';
import { getDashboardSummary, formatCurrency } from '@/lib/data';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { 
  TrendingUpIcon, 
  TrendingDownIcon, 
  AlertTriangleIcon, 
  BarChart3Icon,
  ThumbsUpIcon 
} from 'lucide-react';

export function InsightsPanel() {
  const { transactions, budgets } = useFinanceStore();
  
  const summary = getDashboardSummary(transactions);
  
  // Calculate previous month's data for comparison
  const currentDate = new Date();
  const currentMonth = currentDate.toISOString().substring(0, 7); // YYYY-MM format
  
  // Get previous month in YYYY-MM format
  const previousMonth = new Date(
    currentDate.getFullYear(),
    currentDate.getMonth() - 1
  ).toISOString().substring(0, 7);
  
  // Filter transactions for current and previous months
  const currentMonthTransactions = transactions.filter(
    t => t.date.startsWith(currentMonth)
  );
  const previousMonthTransactions = transactions.filter(
    t => t.date.startsWith(previousMonth)
  );
  
  const currentMonthSummary = getDashboardSummary(currentMonthTransactions);
  const previousMonthSummary = getDashboardSummary(previousMonthTransactions);
  
  // Calculate month-over-month changes
  const expenseChange = previousMonthSummary.totalExpenses > 0
    ? ((currentMonthSummary.totalExpenses - previousMonthSummary.totalExpenses) / 
       previousMonthSummary.totalExpenses * 100)
    : 0;
  
  const incomeChange = previousMonthSummary.totalIncome > 0
    ? ((currentMonthSummary.totalIncome - previousMonthSummary.totalIncome) / 
       previousMonthSummary.totalIncome * 100)
    : 0;
  
  // Generate insights based on spending patterns
  const generateInsights = () => {
    const insights = [];
    
    // Check savings rate
    const savingsRate = summary.totalIncome > 0
      ? (summary.netSavings / summary.totalIncome) * 100
      : 0;
    
    if (savingsRate >= 20) {
      insights.push({
        type: 'positive',
        icon: <ThumbsUpIcon className="h-5 w-5 text-green-500" />,
        message: `Great job! You're saving ${savingsRate.toFixed(1)}% of your income.`
      });
    } else if (savingsRate > 0) {
      insights.push({
        type: 'neutral',
        icon: <BarChart3Icon className="h-5 w-5 text-blue-500" />,
        message: `You're saving ${savingsRate.toFixed(1)}% of your income. Aim for 20%.`
      });
    } else {
      insights.push({
        type: 'negative',
        icon: <AlertTriangleIcon className="h-5 w-5 text-red-500" />,
        message: "Your expenses exceed your income. Consider reducing expenses."
      });
    }
    
    // Check for overspending in categories
    const currentMonthBudgets = budgets.filter(b => b.month === currentMonth);
    if (currentMonthBudgets.length > 0) {
      let overBudgetCategories = 0;
      
      currentMonthBudgets.forEach(budget => {
        const actual = currentMonthTransactions
          .filter(t => t.categoryId === budget.categoryId && t.type === 'expense')
          .reduce((sum, t) => sum + t.amount, 0);
        
        if (actual > budget.budget) {
          overBudgetCategories++;
        }
      });
      
      if (overBudgetCategories > 0) {
        insights.push({
          type: 'negative',
          icon: <TrendingUpIcon className="h-5 w-5 text-red-500" />,
          message: `You're over budget in ${overBudgetCategories} ${
            overBudgetCategories === 1 ? 'category' : 'categories'
          }.`
        });
      }
    }
    
    // Check expense trend
    if (Math.abs(expenseChange) > 10) {
      insights.push({
        type: expenseChange > 0 ? 'negative' : 'positive',
        icon: expenseChange > 0 
          ? <TrendingUpIcon className="h-5 w-5 text-red-500" />
          : <TrendingDownIcon className="h-5 w-5 text-green-500" />,
        message: `Your expenses ${expenseChange > 0 ? 'increased' : 'decreased'} by ${
          Math.abs(expenseChange).toFixed(1)
        }% compared to last month.`
      });
    }
    
    return insights;
  };
  
  const insights = generateInsights();

  return (
    <Card>
      <CardHeader>
        <CardTitle>Financial Insights</CardTitle>
        <CardDescription>
          Smart tips based on your spending patterns
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {insights.map((insight, index) => (
            <div
              key={index}
              className={`flex p-4 rounded-md items-start space-x-3 ${
                insight.type === 'positive'
                  ? 'bg-green-50 border border-green-200'
                  : insight.type === 'negative'
                  ? 'bg-red-50 border border-red-200'
                  : 'bg-blue-50 border border-blue-200'
              }`}
            >
              <div className="mt-0.5">
                {insight.icon}
              </div>
              <div>
                <p className={`text-sm ${
                  insight.type === 'positive'
                    ? 'text-green-700'
                    : insight.type === 'negative'
                    ? 'text-red-700'
                    : 'text-blue-700'
                }`}>
                  {insight.message}
                </p>
              </div>
            </div>
          ))}
          
          {insights.length === 0 && (
            <p className="text-center text-muted-foreground py-4">
              Not enough data to generate insights
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}