'use client';

import { useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { format, parse } from 'date-fns';

import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useFinanceStore } from '@/lib/store';
import { Budget } from '@/lib/types';
import { categories } from '@/lib/data';

const months = [];
const currentDate = new Date();
for (let i = 0; i < 12; i++) {
  const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
  const monthKey = format(date, 'yyyy-MM');
  const monthDisplay = format(date, 'MMMM yyyy');
  months.push({ key: monthKey, display: monthDisplay });
}

const formSchema = z.object({
  categoryId: z.string(),
  amount: z.coerce.number().positive({ message: "Amount must be positive" }),
  month: z.string(),
});

type BudgetFormValues = z.infer<typeof formSchema>;

interface BudgetFormProps {
  budget?: Budget;
  onSuccess?: () => void;
}

export function BudgetForm({ budget, onSuccess }: BudgetFormProps) {
  const { addBudget, updateBudget } = useFinanceStore();
  
  // Default values for the form
  const defaultValues: Partial<BudgetFormValues> = budget
    ? {
        categoryId: budget.categoryId,
        amount: budget.amount,
        month: budget.month,
      }
    : {
        categoryId: '',
        amount: 0,
        month: format(new Date(), 'yyyy-MM'),
      };

  const form = useForm<BudgetFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
  });

  const onSubmit = (values: BudgetFormValues) => {
    if (budget) {
      updateBudget({ ...values, id: budget.id });
    } else {
      addBudget(values);
    }

    form.reset(defaultValues);
    onSuccess?.();
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="month"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Month</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select month" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {months.map((month) => (
                    <SelectItem key={month.key} value={month.key}>
                      {month.display}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormDescription>
                The month this budget applies to.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="categoryId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Category</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {categories
                    .filter(c => c.id !== 'income') // Filter out income category
                    .map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
              <FormDescription>
                The spending category for this budget.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="amount"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Amount</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  {...field}
                />
              </FormControl>
              <FormDescription>
                Your monthly budget limit for this category.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-2">
          <Button 
            type="button" 
            variant="outline" 
            onClick={() => form.reset(defaultValues)}
          >
            Cancel
          </Button>
          <Button type="submit">
            {budget ? 'Update' : 'Add'} Budget
          </Button>
        </div>
      </form>
    </Form>
  );
}