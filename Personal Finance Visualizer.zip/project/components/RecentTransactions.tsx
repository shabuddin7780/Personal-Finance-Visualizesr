'use client';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { useFinanceStore } from '@/lib/store';
import { formatCurrency, formatDate, getCategoryById } from '@/lib/data';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

export function RecentTransactions() {
  const { transactions } = useFinanceStore();
  
  // Sort by date (newest first) and take the most recent 5
  const recentTransactions = [...transactions]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Transactions</CardTitle>
        <CardDescription>Your latest 5 transactions</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentTransactions.length > 0 ? (
            recentTransactions.map((transaction) => {
              const category = getCategoryById(transaction.categoryId);
              
              return (
                <div
                  key={transaction.id}
                  className="flex items-center justify-between space-x-4 rounded-md border p-4"
                >
                  <div className="flex items-center space-x-4">
                    <div
                      className="rounded-full p-2"
                      style={{ backgroundColor: category?.color + '20' }}
                    >
                      <div
                        className="h-8 w-8 rounded-full flex items-center justify-center"
                        style={{ backgroundColor: category?.color }}
                      >
                        {/* Icon for category */}
                        <span className="text-white font-bold text-sm">
                          {category?.name.substring(0, 1)}
                        </span>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-medium leading-none">
                        {transaction.description}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {formatDate(transaction.date)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge
                      variant="outline"
                      style={{
                        backgroundColor: category?.color + '20',
                        color: category?.color,
                      }}
                    >
                      {category?.name}
                    </Badge>
                    <p
                      className={cn(
                        "text-sm font-bold",
                        transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                      )}
                    >
                      {transaction.type === 'income' ? '+' : '-'}
                      {formatCurrency(transaction.amount)}
                    </p>
                  </div>
                </div>
              );
            })
          ) : (
            <p className="text-center text-muted-foreground py-4">
              No recent transactions
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}