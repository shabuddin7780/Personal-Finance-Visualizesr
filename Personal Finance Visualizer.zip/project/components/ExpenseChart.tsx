'use client';

import { useRef, useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Label,
} from 'recharts';
import { format, parseISO, subMonths } from 'date-fns';
import { ChevronLeft, ChevronRight } from 'lucide-react';

import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { useFinanceStore } from '@/lib/store';
import { getMonthlyData, formatCurrency } from '@/lib/data';

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-4 rounded-md shadow-md border border-gray-200">
        <p className="font-bold">{format(parseISO(label), 'MMMM yyyy')}</p>
        <p className="text-[hsl(var(--primary))]">
          {formatCurrency(payload[0].value)}
        </p>
      </div>
    );
  }

  return null;
};

export function ExpenseChart() {
  const { transactions } = useFinanceStore();
  const [monthsToShow, setMonthsToShow] = useState(6);
  
  // Get current date and calculate date range
  const currentDate = new Date();
  const startDate = subMonths(currentDate, monthsToShow);
  
  // Filter transactions for the date range
  const filteredTransactions = transactions.filter(transaction => {
    const transactionDate = new Date(transaction.date);
    return (
      transaction.type === 'expense' && 
      transactionDate >= startDate && 
      transactionDate <= currentDate
    );
  });
  
  // Process data for the chart
  const monthlyData = getMonthlyData(filteredTransactions);
  
  // Format labels for the X-axis
  const formattedData = monthlyData.map(item => ({
    ...item,
    formattedMonth: format(parseISO(item.month), 'MMM yy')
  }));
  
  // Calculate total expenses for the period
  const totalExpenses = monthlyData.reduce((sum, item) => sum + item.amount, 0);
  
  // Functions to navigate the chart
  const handleShowMore = () => {
    setMonthsToShow(prev => prev + 3);
  };
  
  const handleShowLess = () => {
    if (monthsToShow > 3) {
      setMonthsToShow(prev => prev - 3);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Monthly Expenses</CardTitle>
        <CardDescription>
          Your spending over the past {monthsToShow} months
        </CardDescription>
      </CardHeader>
      <CardContent className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={formattedData}
            margin={{ top: 10, right: 10, left: 10, bottom: 20 }}
          >
            <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
            <XAxis 
              dataKey="month" 
              tickFormatter={(tick) => format(parseISO(tick), 'MMM')}
              angle={-45}
              textAnchor="end"
              height={50}
            />
            <YAxis
              tickFormatter={(value) => `$${value}`}
              width={60}
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar
              dataKey="amount"
              fill="hsl(var(--chart-1))"
              radius={[4, 4, 0, 0]}
              animationDuration={1000}
            />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
      <CardFooter className="flex justify-between items-center">
        <div className="text-sm text-muted-foreground">
          Total: <span className="font-medium">{formatCurrency(totalExpenses)}</span>
        </div>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleShowLess}
            disabled={monthsToShow <= 3}
          >
            <ChevronLeft className="mr-1 h-4 w-4" />
            Show Less
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleShowMore}
          >
            Show More
            <ChevronRight className="ml-1 h-4 w-4" />
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}