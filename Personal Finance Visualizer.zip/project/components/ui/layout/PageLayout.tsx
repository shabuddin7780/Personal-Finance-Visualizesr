'use client';

import { ReactNode, useState } from 'react';
import Link from 'next/link';
import {
  LayoutDashboardIcon,
  ListIcon,
  PiggyBankIcon,
  SettingsIcon,
  MenuIcon,
  XIcon,
  LineChartIcon,
} from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface NavItemProps {
  href: string;
  icon: ReactNode;
  label: string;
  isActive: boolean;
}

function NavItem({ href, icon, label, isActive }: NavItemProps) {
  return (
    <Link
      href={href}
      className={cn(
        "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all",
        isActive
          ? "bg-primary/10 text-primary"
          : "text-muted-foreground hover:bg-primary/5 hover:text-primary"
      )}
    >
      {icon}
      {label}
    </Link>
  );
}

interface PageLayoutProps {
  children: ReactNode;
  currentPage: string;
}

export function PageLayout({ children, currentPage }: PageLayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  const navItems = [
    {
      href: '/',
      icon: <LayoutDashboardIcon className="h-4 w-4" />,
      label: 'Dashboard',
      path: '/'
    },
    {
      href: '/transactions',
      icon: <ListIcon className="h-4 w-4" />,
      label: 'Transactions',
      path: '/transactions'
    },
    {
      href: '/budgets',
      icon: <PiggyBankIcon className="h-4 w-4" />,
      label: 'Budgets',
      path: '/budgets'
    },
    {
      href: '/insights',
      icon: <LineChartIcon className="h-4 w-4" />,
      label: 'Insights',
      path: '/insights'
    },
  ];

  return (
    <div className="flex min-h-screen flex-col">
      {/* Mobile Header */}
      <header className="sticky top-0 z-30 flex h-14 items-center gap-4 border-b bg-background px-4 sm:static md:hidden">
        <Sheet open={isSidebarOpen} onOpenChange={setIsSidebarOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden">
              <MenuIcon className="h-6 w-6" />
              <span className="sr-only">Toggle Menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[240px] sm:w-[300px]">
            <nav className="flex flex-col gap-2 mt-6">
              {navItems.map((item) => (
                <NavItem
                  key={item.href}
                  href={item.href}
                  icon={item.icon}
                  label={item.label}
                  isActive={currentPage === item.path}
                />
              ))}
            </nav>
          </SheetContent>
        </Sheet>
        <div className="flex-1">
          <h1 className="text-xl font-semibold">Finance Visualizer</h1>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Sidebar - desktop */}
        <aside className="hidden w-[240px] flex-col border-r bg-background md:flex">
          <div className="flex h-14 items-center border-b px-6">
            <Link href="/" className="flex items-center gap-2 font-semibold">
              <PiggyBankIcon className="h-6 w-6" />
              <span>Finance Visualizer</span>
            </Link>
          </div>
          <nav className="flex-1 space-y-1 p-4">
            {navItems.map((item) => (
              <NavItem
                key={item.href}
                href={item.href}
                icon={item.icon}
                label={item.label}
                isActive={currentPage === item.path}
              />
            ))}
          </nav>
          <div className="mt-auto border-t p-4">
            <Button variant="outline" className="w-full" size="sm">
              <SettingsIcon className="mr-2 h-4 w-4" />
              Settings
            </Button>
          </div>
        </aside>

        {/* Main content */}
        <main className="flex-1 p-4 md:p-8">{children}</main>
      </div>
    </div>
  );
}