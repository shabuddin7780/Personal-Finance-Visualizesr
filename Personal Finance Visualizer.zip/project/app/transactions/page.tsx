'use client';

import { PageLayout } from '@/components/ui/layout/PageLayout';
import { TransactionList } from '@/components/TransactionList';

export default function TransactionsPage() {
  return (
    <PageLayout currentPage="/transactions">
      <div className="flex flex-col gap-6">
        <TransactionList />
      </div>
    </PageLayout>
  );
}