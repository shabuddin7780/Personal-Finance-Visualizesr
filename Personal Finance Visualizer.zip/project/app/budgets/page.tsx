'use client';

import { PageLayout } from '@/components/ui/layout/PageLayout';
import { BudgetList } from '@/components/BudgetList';
import { BudgetComparisonChart } from '@/components/BudgetComparisonChart';

export default function BudgetsPage() {
  return (
    <PageLayout currentPage="/budgets">
      <div className="flex flex-col gap-6">
        <h1 className="text-3xl font-bold">Budget Management</h1>
        <BudgetComparisonChart />
        <BudgetList />
      </div>
    </PageLayout>
  );
}