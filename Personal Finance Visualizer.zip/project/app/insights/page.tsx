'use client';

import { PageLayout } from '@/components/ui/layout/PageLayout';
import { ExpenseChart } from '@/components/ExpenseChart';
import { CategoryPieChart } from '@/components/CategoryPieChart';
import { BudgetComparisonChart } from '@/components/BudgetComparisonChart';
import { InsightsPanel } from '@/components/InsightsPanel';

export default function InsightsPage() {
  return (
    <PageLayout currentPage="/insights">
      <div className="flex flex-col gap-6">
        <h1 className="text-3xl font-bold">Financial Insights</h1>
        
        <div className="grid grid-cols-1 gap-6">
          <InsightsPanel />
        </div>
        
        <h2 className="text-xl font-semibold mt-4">Spending Analysis</h2>
        <div className="grid gap-6 md:grid-cols-2">
          <ExpenseChart />
          <CategoryPieChart />
        </div>
        
        <h2 className="text-xl font-semibold mt-4">Budget Performance</h2>
        <BudgetComparisonChart />
      </div>
    </PageLayout>
  );
}