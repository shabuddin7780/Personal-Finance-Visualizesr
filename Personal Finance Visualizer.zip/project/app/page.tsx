'use client';

import { useEffect, useState } from 'react';
import { PageLayout } from '@/components/ui/layout/PageLayout';
import { DashboardCard } from '@/components/DashboardCard';
import { ExpenseChart } from '@/components/ExpenseChart';
import { CategoryPieChart } from '@/components/CategoryPieChart';
import { RecentTransactions } from '@/components/RecentTransactions';
import { InsightsPanel } from '@/components/InsightsPanel';
import { useFinanceStore } from '@/lib/store';
import { getDashboardSummary } from '@/lib/data';
import { Skeleton } from '@/components/ui/skeleton';

export default function Home() {
  const { transactions } = useFinanceStore();
  const [isLoading, setIsLoading] = useState(true);
  
  // Calculate month-over-month changes for dashboard cards
  const currentDate = new Date();
  const currentMonth = currentDate.toISOString().substring(0, 7); // YYYY-MM format
  
  // Get previous month in YYYY-MM format
  const previousMonth = new Date(
    currentDate.getFullYear(),
    currentDate.getMonth() - 1
  ).toISOString().substring(0, 7);
  
  // Filter transactions for current and previous months
  const currentMonthTransactions = transactions.filter(
    t => t.date.startsWith(currentMonth)
  );
  const previousMonthTransactions = transactions.filter(
    t => t.date.startsWith(previousMonth)
  );
  
  const currentMonthSummary = getDashboardSummary(currentMonthTransactions);
  const previousMonthSummary = getDashboardSummary(previousMonthTransactions);
  
  // Calculate month-over-month changes
  const expenseChange = previousMonthSummary.totalExpenses > 0
    ? ((currentMonthSummary.totalExpenses - previousMonthSummary.totalExpenses) / 
       previousMonthSummary.totalExpenses * 100)
    : 0;
  
  const incomeChange = previousMonthSummary.totalIncome > 0
    ? ((currentMonthSummary.totalIncome - previousMonthSummary.totalIncome) / 
       previousMonthSummary.totalIncome * 100)
    : 0;
  
  const savingsChange = previousMonthSummary.netSavings > 0
    ? ((currentMonthSummary.netSavings - previousMonthSummary.netSavings) / 
       previousMonthSummary.netSavings * 100)
    : 0;
  
  // Simulate loading state
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  return (
    <PageLayout currentPage="/">
      <div className="flex flex-col gap-6">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        
        {isLoading ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <DashboardCard
              title="Total Income"
              value={currentMonthSummary.totalIncome}
              type="income"
              change={incomeChange}
            />
            <DashboardCard
              title="Total Expenses"
              value={currentMonthSummary.totalExpenses}
              type="expense"
              change={expenseChange}
            />
            <DashboardCard
              title="Net Savings"
              value={currentMonthSummary.netSavings}
              type={currentMonthSummary.netSavings >= 0 ? 'income' : 'expense'}
              change={savingsChange}
            />
            <DashboardCard
              title="Top Expense"
              value={currentMonthSummary.topExpenseCategory.amount}
              type="expense"
            />
          </div>
        )}
        
        {isLoading ? (
          <div className="grid gap-6 md:grid-cols-2">
            <Skeleton className="h-96" />
            <Skeleton className="h-96" />
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2">
            <ExpenseChart />
            <CategoryPieChart />
          </div>
        )}
        
        {isLoading ? (
          <div className="grid gap-6 md:grid-cols-2">
            <Skeleton className="h-80" />
            <Skeleton className="h-80" />
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2">
            <RecentTransactions />
            <InsightsPanel />
          </div>
        )}
      </div>
    </PageLayout>
  );
}