// Type definitions for the Personal Finance Visualizer

export type Transaction = {
  id: string;
  amount: number;
  date: string;
  description: string;
  categoryId: string;
  type: 'income' | 'expense';
};

export type Category = {
  id: string;
  name: string;
  color: string;
  icon: string;
};

export type Budget = {
  id: string;
  categoryId: string;
  amount: number;
  month: string; // Format: YYYY-MM
};

export type MonthlyData = {
  month: string;
  amount: number;
};

export type CategoryData = {
  category: string;
  amount: number;
  color: string;
};

export type BudgetComparisonData = {
  category: string;
  budget: number;
  actual: number;
  color: string;
};

export type DashboardSummary = {
  totalExpenses: number;
  totalIncome: number;
  netSavings: number;
  topExpenseCategory: {
    name: string;
    amount: number;
  };
};