import { Transaction, Category, Budget, MonthlyData, CategoryData, BudgetComparisonData } from '@/lib/types';

// Predefined categories
export const categories: Category[] = [
  { id: 'food', name: 'Food & Dining', color: 'hsl(var(--chart-1))', icon: 'utensils' },
  { id: 'transportation', name: 'Transportation', color: 'hsl(var(--chart-2))', icon: 'car' },
  { id: 'housing', name: 'Housing', color: 'hsl(var(--chart-3))', icon: 'home' },
  { id: 'entertainment', name: 'Entertainment', color: 'hsl(var(--chart-4))', icon: 'film' },
  { id: 'utilities', name: 'Utilities', color: 'hsl(var(--chart-5))', icon: 'plug' },
  { id: 'health', name: 'Health', color: '#4CAF50', icon: 'heart' },
  { id: 'education', name: 'Education', color: '#9C27B0', icon: 'book-open' },
  { id: 'shopping', name: 'Shopping', color: '#FF9800', icon: 'shopping-bag' },
  { id: 'income', name: 'Income', color: '#00BCD4', icon: 'trending-up' },
  { id: 'other', name: 'Other', color: '#607D8B', icon: 'more-horizontal' },
];

// Sample transaction data
export const sampleTransactions: Transaction[] = [
  {
    id: '1',
    amount: 45.99,
    date: '2023-04-01',
    description: 'Grocery shopping',
    categoryId: 'food',
    type: 'expense',
  },
  {
    id: '2',
    amount: 25.50,
    date: '2023-04-03',
    description: 'Gas station',
    categoryId: 'transportation',
    type: 'expense',
  },
  {
    id: '3',
    amount: 1200.00,
    date: '2023-04-05',
    description: 'Rent payment',
    categoryId: 'housing',
    type: 'expense',
  },
  {
    id: '4',
    amount: 3000.00,
    date: '2023-04-01',
    description: 'Salary',
    categoryId: 'income',
    type: 'income',
  },
  {
    id: '5',
    amount: 15.99,
    date: '2023-04-08',
    description: 'Movie tickets',
    categoryId: 'entertainment',
    type: 'expense',
  },
  {
    id: '6',
    amount: 89.99,
    date: '2023-04-10',
    description: 'Electricity bill',
    categoryId: 'utilities',
    type: 'expense',
  },
  {
    id: '7',
    amount: 42.00,
    date: '2023-04-12',
    description: 'Pharmacy',
    categoryId: 'health',
    type: 'expense',
  },
  {
    id: '8',
    amount: 120.00,
    date: '2023-04-15',
    description: 'Online course',
    categoryId: 'education',
    type: 'expense',
  },
];

// Sample budgets
export const sampleBudgets: Budget[] = [
  { id: '1', categoryId: 'food', amount: 400, month: '2023-04' },
  { id: '2', categoryId: 'transportation', amount: 200, month: '2023-04' },
  { id: '3', categoryId: 'housing', amount: 1500, month: '2023-04' },
  { id: '4', categoryId: 'entertainment', amount: 100, month: '2023-04' },
  { id: '5', categoryId: 'utilities', amount: 150, month: '2023-04' },
];

// Helper functions to process data for charts
export function getMonthlyData(transactions: Transaction[]): MonthlyData[] {
  // Group transactions by month and calculate total amount
  const monthlyData: Record<string, number> = {};
  
  transactions.forEach(transaction => {
    if (transaction.type === 'expense') {
      const month = transaction.date.substring(0, 7); // Extract YYYY-MM
      if (!monthlyData[month]) {
        monthlyData[month] = 0;
      }
      monthlyData[month] += transaction.amount;
    }
  });
  
  // Convert to array format required by Recharts
  return Object.entries(monthlyData)
    .map(([month, amount]) => ({ month, amount }))
    .sort((a, b) => a.month.localeCompare(b.month));
}

export function getCategoryData(transactions: Transaction[]): CategoryData[] {
  // Group transactions by category and calculate total amount
  const categoryData: Record<string, number> = {};
  
  transactions.forEach(transaction => {
    if (transaction.type === 'expense') {
      if (!categoryData[transaction.categoryId]) {
        categoryData[transaction.categoryId] = 0;
      }
      categoryData[transaction.categoryId] += transaction.amount;
    }
  });
  
  // Convert to array format required by Recharts and add category name and color
  return Object.entries(categoryData).map(([categoryId, amount]) => {
    const category = categories.find(c => c.id === categoryId);
    return {
      category: category ? category.name : 'Unknown',
      amount,
      color: category ? category.color : '#999',
    };
  });
}

export function getBudgetComparisonData(
  transactions: Transaction[],
  budgets: Budget[],
  month: string
): BudgetComparisonData[] {
  // Filter transactions for the selected month
  const monthlyTransactions = transactions.filter(t => 
    t.type === 'expense' && t.date.startsWith(month)
  );
  
  // Calculate actual expenses by category
  const categoryExpenses: Record<string, number> = {};
  monthlyTransactions.forEach(transaction => {
    if (!categoryExpenses[transaction.categoryId]) {
      categoryExpenses[transaction.categoryId] = 0;
    }
    categoryExpenses[transaction.categoryId] += transaction.amount;
  });
  
  // Create comparison data from budgets
  return budgets
    .filter(b => b.month === month)
    .map(budget => {
      const category = categories.find(c => c.id === budget.categoryId);
      const actual = categoryExpenses[budget.categoryId] || 0;
      
      return {
        category: category ? category.name : 'Unknown',
        budget: budget.amount,
        actual,
        color: category ? category.color : '#999',
      };
    });
}

export function getDashboardSummary(transactions: Transaction[]) {
  let totalExpenses = 0;
  let totalIncome = 0;
  const categoryExpenses: Record<string, number> = {};
  
  transactions.forEach(transaction => {
    if (transaction.type === 'expense') {
      totalExpenses += transaction.amount;
      
      if (!categoryExpenses[transaction.categoryId]) {
        categoryExpenses[transaction.categoryId] = 0;
      }
      categoryExpenses[transaction.categoryId] += transaction.amount;
    } else {
      totalIncome += transaction.amount;
    }
  });
  
  // Find top expense category
  let topCategoryId = '';
  let topAmount = 0;
  
  Object.entries(categoryExpenses).forEach(([categoryId, amount]) => {
    if (amount > topAmount) {
      topCategoryId = categoryId;
      topAmount = amount;
    }
  });
  
  const topCategory = categories.find(c => c.id === topCategoryId);
  
  return {
    totalExpenses,
    totalIncome,
    netSavings: totalIncome - totalExpenses,
    topExpenseCategory: {
      name: topCategory ? topCategory.name : 'None',
      amount: topAmount,
    },
  };
}

// Format currency
export function formatCurrency(amount: number): string {
  return amount.toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
  });
}

// Format date for display
export function formatDate(dateString: string): string {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function getCategoryById(categoryId: string): Category | undefined {
  return categories.find(category => category.id === categoryId);
}

// Generate a unique ID
export function generateId(): string {
  return Math.random().toString(36).substring(2, 9);
}