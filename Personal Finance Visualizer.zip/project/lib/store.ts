import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { 
  Transaction, 
  Budget, 
  Category 
} from '@/lib/types';
import { 
  sampleTransactions, 
  sampleBudgets, 
  categories, 
  generateId 
} from '@/lib/data';

interface FinanceState {
  transactions: Transaction[];
  budgets: Budget[];
  categories: Category[];
  addTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  updateTransaction: (transaction: Transaction) => void;
  deleteTransaction: (id: string) => void;
  addBudget: (budget: Omit<Budget, 'id'>) => void;
  updateBudget: (budget: Budget) => void;
  deleteBudget: (id: string) => void;
}

export const useFinanceStore = create<FinanceState>()(
  persist(
    (set) => ({
      transactions: sampleTransactions,
      budgets: sampleBudgets,
      categories: categories,
      
      addTransaction: (transactionData) => 
        set((state) => ({
          transactions: [
            ...state.transactions,
            { id: generateId(), ...transactionData },
          ],
        })),
      
      updateTransaction: (updatedTransaction) =>
        set((state) => ({
          transactions: state.transactions.map((transaction) =>
            transaction.id === updatedTransaction.id 
              ? updatedTransaction 
              : transaction
          ),
        })),
      
      deleteTransaction: (id) =>
        set((state) => ({
          transactions: state.transactions.filter(
            (transaction) => transaction.id !== id
          ),
        })),
      
      addBudget: (budgetData) =>
        set((state) => ({
          budgets: [
            ...state.budgets,
            { id: generateId(), ...budgetData },
          ],
        })),
      
      updateBudget: (updatedBudget) =>
        set((state) => ({
          budgets: state.budgets.map((budget) =>
            budget.id === updatedBudget.id ? updatedBudget : budget
          ),
        })),
      
      deleteBudget: (id) =>
        set((state) => ({
          budgets: state.budgets.filter((budget) => budget.id !== id),
        })),
    }),
    {
      name: 'finance-storage',
    }
  )
);